import asyncio
from pyrogram.errors import FloodWait
from Extractor import apps
from config import PREMIUM_LOGS
import random

class MultiBotSender:
    @staticmethod
    async def send_document(chat_id, document, caption=None, reply_to_message_id=None):
        """
        Try sending a document using available bots.
        Rotates through bots to distribute load and handle FloodWait.
        """
        last_exception = None
        num_bots = len(apps)
        
        # Randomize start index for load balancing
        start_index = random.randint(0, num_bots - 1)
        
        for i in range(num_bots):
            # Calculate actual bot index using modulo to wrap around
            bot_index = (start_index + i) % num_bots
            client = apps[bot_index]
            
            try:
                # print(f"[SENDER] Trying with bot {bot_index} ({client.name})...")
                await client.send_document(
                    chat_id=chat_id,
                    document=document,
                    caption=caption,
                    reply_to_message_id=reply_to_message_id
                )
                print(f"[SENDER] Success with bot {bot_index}!")
                return # Success
            except FloodWait as e:
                print(f"[SENDER] Bot {bot_index} hit FloodWait: {e.value}s. Switching...")
                last_exception = e
                continue # Try next bot
            except Exception as e:
                print(f"[SENDER] Bot {bot_index} failed with error: {e}")
                last_exception = e
                continue
        
        print(f"[SENDER] All bots failed to send document to {chat_id}")
        if last_exception:
            raise last_exception

    @staticmethod
    async def send_message(chat_id, text, reply_to_message_id=None, disable_web_page_preview=True):
        """
        Try sending a text message using available bots.
        """
        last_exception = None
        num_bots = len(apps)
        
        # Randomize start index for load balancing
        start_index = random.randint(0, num_bots - 1)
        
        for i in range(num_bots):
            # Calculate actual bot index using modulo to wrap around
            bot_index = (start_index + i) % num_bots
            client = apps[bot_index]
            
            try:
                # print(f"[SENDER] Sending message with bot {bot_index} ({client.name})...")
                sent = await client.send_message(
                    chat_id=chat_id,
                    text=text,
                    reply_to_message_id=reply_to_message_id,
                    disable_web_page_preview=disable_web_page_preview
                )
                return sent
            except FloodWait as e:
                print(f"[SENDER] Bot {bot_index} hit FloodWait: {e.value}s. Switching...")
                last_exception = e
                continue
            except Exception as e:
                print(f"[SENDER] Bot {bot_index} failed to send message: {e}")
                last_exception = e
                continue
        
        print(f"[SENDER] All bots failed to send message to {chat_id}")
        raise last_exception

    @staticmethod
    async def edit_message(client, chat_id, message_id, text):
        """
        Try editing a message. 
        If the original bot (client) is floodwaited, we CANNOT edit the message with another bot.
        In that case, we must send a NEW message with the new content using a healthy bot.
        """
        try:
            await client.edit_message_text(chat_id=chat_id, message_id=message_id, text=text)
        except FloodWait as e:
            print(f"[SENDER] Edit failed due to FloodWait: {e.value}s. Sending new message...")
            # Fallback: Send a new message using MultiBotSender
            await MultiBotSender.send_message(chat_id, text)
        except Exception as e:
            print(f"[SENDER] Edit failed: {e}. Sending new message...")
            await MultiBotSender.send_message(chat_id, text)

    @staticmethod
    async def send_document_with_fallback(client, message, document, caption, channel_id=None):
        """
        High-level wrapper to send to channel with fallback to user's private chat.
        """
        target_id = channel_id if channel_id else message.chat.id
        
        try:
            await MultiBotSender.send_document(target_id, document, caption)
            
            # If sent to channel, also send to PREMIUM_LOGS if configured
            if channel_id and PREMIUM_LOGS:
                 try:
                     await MultiBotSender.send_document(PREMIUM_LOGS, document, caption)
                 except:
                     pass
                     
        except Exception as e:
            print(f"[SENDER] Failed to send to target {target_id}. Trying fallback to user {message.chat.id}")
            try:
                await MultiBotSender.send_document(message.chat.id, document, caption)
                # Use safe send_message for the error notification
                await MultiBotSender.send_message(
                    message.chat.id,
                    f"⚠️ **Channel Upload Failed**\n"
                    f"Sent file to private chat instead.\n"
                    f"Error: `{e}`"
                )
            except Exception as fallback_error:
                print(f"[SENDER] Fallback also failed: {fallback_error}")
                raise fallback_error
