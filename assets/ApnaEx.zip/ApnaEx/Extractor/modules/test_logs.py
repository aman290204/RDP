from pyrogram import filters
from pyrogram.handlers import MessageHandler
from Extractor import apps
from config import SCANNER_LOG_CHANNEL

async def test_logs_command(client, message):
    """
    Test command to verify bot permissions in the scanner log channel.
    Each bot will attempt to send a message to the configured channel.
    """
    user_msg = await message.reply_text(f"🧪 Testing logs for {len(apps)} bots to channel `{SCANNER_LOG_CHANNEL}`...")
    
    success_count = 0
    
    for i, bot in enumerate(apps):
        try:
            # client.me is populated after start()
            bot_name = bot.me.first_name if bot.me else f"Bot {i+1}"
            bot_username = f"@{bot.me.username}" if bot.me and bot.me.username else "No Username"
            
            await bot.send_message(
                SCANNER_LOG_CHANNEL, 
                f"✅ **Test Log**\n"
                f"🤖 **Bot:** {bot_name} ({bot_username})\n"
                f"🆔 **ID:** `{bot.me.id}`\n"
                f"👤 **Triggered By:** {message.from_user.mention}"
            )
            success_count += 1
        except Exception as e:
            await message.reply_text(f"❌ **Bot {i+1} Failed:**\n`{e}`")
            
    await user_msg.edit_text(f"✅ **Test Complete**\n\nSent {success_count}/{len(apps)} messages to `{SCANNER_LOG_CHANNEL}`.")

# Register handler for all bots
print("[TEST_LOGS] Registering /testlogs handler...")
for client in apps:
    client.add_handler(MessageHandler(test_logs_command, filters.command("testlogs")))
