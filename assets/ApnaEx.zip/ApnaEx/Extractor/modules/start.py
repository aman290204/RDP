from pyrogram import filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message
from config import BOT_USERNAME
from Extractor import app

from pyrogram import filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message
from pyrogram.handlers import MessageHandler
from config import BOT_USERNAME
from Extractor import apps

custom_button = [[
                  InlineKeyboardButton("🎯 CʟᴀssPʟᴜs 🎯", callback_data="cpwp")
                ],[
                  InlineKeyboardButton("𝐁 𝐀 𝐂 𝐊", callback_data="modes_")
                ]]

async def start(bot, message: Message):
    await message.reply_text(
        text=f"Hello {message.from_user.mention},\n\nI am {BOT_USERNAME}. Click the button below to start.",
        reply_markup=InlineKeyboardMarkup(custom_button)
    )

# Register handlers for ALL bots
print("[START] Registering handlers for all bots...")
for client in apps:
    client.add_handler(MessageHandler(start, filters.command("start")))
print(f"[START] Handlers registered for {len(apps)} bots.")