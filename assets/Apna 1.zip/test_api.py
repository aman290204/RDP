import aiohttp
import asyncio

async def test_org_details(org_code):
    url = "https://api.classplusapp.com/v2/org/details"
    headers = {
        'user-agent': 'Mobile-Android',
        'app-version': '1.4.65.3',
        'api-version': '29',
        'device-id': '39F093FF35F201D9',
        'orgId': org_code # Guessing parameter name
    }
    
    # Also try with query param
    url_query = f"{url}?orgId={org_code}"
    
    async with aiohttp.ClientSession() as session:
        print(f"Testing {url} with headers...")
        async with session.get(url, headers=headers) as resp:
            print(f"Status: {resp.status}")
            print(f"Response: {await resp.text()}")
            
        print(f"\nTesting {url_query}...")
        async with session.get(url_query, headers=headers) as resp:
            print(f"Status: {resp.status}")
            print(f"Response: {await resp.text()}")

if __name__ == "__main__":
    # Use a known valid code, e.g., 'kalyan' or one found in logs
    asyncio.run(test_org_details("kalyan"))
