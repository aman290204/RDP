import sys
import os

# Add the parent directory to sys.path to import modules if needed, 
# but here we will just copy the logic to test it in isolation for speed/safety
# or we can import if we are sure about dependencies. 
# Let's copy the logic to be 100% sure we are testing the ALGORITHM.

def compare_codes(code1, code2):
    """
    Compare two codes based on length first, then lexicographically.
    Returns:
        -1 if code1 < code2
         0 if code1 == code2
         1 if code1 > code2
    """
    if len(code1) < len(code2):
        return -1
    elif len(code1) > len(code2):
        return 1
    else:
        if code1 < code2:
            return -1
        elif code1 > code2:
            return 1
        else:
            return 0

def next_code(code):
    """Generate the next org code (variable length: aa -> ab -> ... -> zz -> aaa -> ...)."""
    chars = list(code)
    i = len(chars) - 1
    
    while i >= 0:
        if chars[i] == 'z':
            chars[i] = 'a'
            i -= 1
        else:
            chars[i] = chr(ord(chars[i]) + 1)
            return "".join(chars)
    
    # If we overflow (all z's), add a new character
    return 'a' * (len(chars) + 1)

def test():
    print("Testing compare_codes...")
    assert compare_codes("aa", "ab") == -1
    assert compare_codes("ab", "aa") == 1
    assert compare_codes("aa", "aa") == 0
    assert compare_codes("zz", "aaa") == -1 # Length priority
    assert compare_codes("aaa", "zz") == 1
    print("compare_codes passed!")

    print("Testing next_code...")
    assert next_code("aa") == "ab"
    assert next_code("az") == "ba"
    assert next_code("zz") == "aaa"
    assert next_code("zzz") == "aaaa"
    print("next_code passed!")

    print("Testing range logic...")
    start = "zy"
    end = "aab"
    current = start
    count = 0
    
    while compare_codes(current, end) <= 0:
        # print(current)
        count += 1
        current = next_code(current)
        if count > 1000: # Safety break
            print("Safety break hit!")
            break
            
    # zy -> zz (2)
    # aaa -> aab (2)
    # Total should be 4: zy, zz, aaa, aab
    print(f"Counted {count} codes from {start} to {end}")
    assert count == 4
    print("Range logic passed!")

if __name__ == "__main__":
    test()
