import asyncio
import json
import os
import re
import time
import aiohttp
import aiofiles
from pyrogram import filters, Client
from pyrogram.errors import FloodWait
from Extractor import app
from config import PREMIUM_LOGS, BOT_TEXT, SCANNER_LOG_CHANNEL, SCANNER_FILE_CHANNEL

# File to store scan progress
PROGRESS_FILE = "scan_progress.json"

class ScanState:
    def __init__(self):
        self.is_scanning = False
        self.current_code = "aa"  # Start from 2 letters
        self.end_code = None      # Stop when this code is reached
        self.found_orgs = []
        self.start_time = 0
        self.scanned_count = 0
        self.load()

    def save(self):
        data = {
            "current_code": self.current_code,
            "end_code": self.end_code,
            "found_orgs": self.found_orgs,
            "scanned_count": self.scanned_count
        }
        with open(PROGRESS_FILE, "w") as f:
            json.dump(data, f)

    def load(self):
        if os.path.exists(PROGRESS_FILE):
            try:
                with open(PROGRESS_FILE, "r") as f:
                    data = json.load(f)
                    self.current_code = data.get("current_code", "aa")
                    self.end_code = data.get("end_code")
                    self.found_orgs = data.get("found_orgs", [])
                    self.scanned_count = data.get("scanned_count", 0)
            except Exception as e:
                print(f"Error loading progress: {e}")

scan_state = ScanState()

# Detect if running on Render/cloud or locally
IS_CLOUD = os.environ.get('RENDER') or os.environ.get('DYNO')

# Semaphore to limit concurrent org processing
# OPTIMAL LIMITS - 200/3200 (Fastest & Stable)
processing_semaphore = asyncio.Semaphore(20 if IS_CLOUD else 200)
# Semaphore to limit concurrent folder fetching within a batch
folder_semaphore = asyncio.Semaphore(50 if IS_CLOUD else 3200)

print(f"[INIT] Running in {'CLOUD' if IS_CLOUD else 'LOCAL'} mode")
print(f"[INIT] Processing semaphore: {20 if IS_CLOUD else 200}")
print(f"[INIT] Folder semaphore: {50 if IS_CLOUD else 3200}")

def compare_codes(code1, code2):
    """
    Compare two codes based on length first, then lexicographically.
    Returns:
        -1 if code1 < code2
         0 if code1 == code2
         1 if code1 > code2
    """
    if len(code1) < len(code2):
        return -1
    elif len(code1) > len(code2):
        return 1
    else:
        if code1 < code2:
            return -1
        elif code1 > code2:
            return 1
        else:
            return 0

def next_code(code):
    """Generate the next org code (variable length: aa -> ab -> ... -> zz -> aaa -> ...)."""
    chars = list(code)
    i = len(chars) - 1
    
    while i >= 0:
        if chars[i] == 'z':
            chars[i] = 'a'
            i -= 1
        else:
            chars[i] = chr(ord(chars[i]) + 1)
            return "".join(chars)
    
    # If we overflow (all z's), add a new character
    return 'a' * (len(chars) + 1)

async def check_org_validity(session, org_code):
    """Check if an org code is valid using the Classplus API."""
    url = f"https://api.classplusapp.com/v2/orgs/{org_code}"
    headers = {
        'user-agent': 'Mobile-Android',
        'app-version': '1.4.65.3',
        'api-version': '29',
        'device-id': '39F093FF35F201D9'
    }
    try:
        # Reduced timeout to 2s for aggressive scanning
        async with session.get(url, headers=headers, timeout=2) as response:
            if response.status == 200:
                data = await response.json()
                if data.get("status") == "success" and data.get("data"):
                    org_data = data["data"]
                    org_name = org_data.get("orgName", "Unknown")
                    
                    # Try to fetch store hash for content extraction
                    store_url = f"https://{org_code}.courses.store"
                    try:
                        async with session.get(store_url, timeout=2) as store_response:
                            if store_response.status == 200:
                                text = await store_response.text()
                                hash_match = re.search(r'"hash":"(.*?)"', text)
                                if hash_match:
                                    return True, hash_match.group(1), org_name
                    except:
                        pass
                    
                    # Valid org even if hash not found
                    return True, None, org_name
            return False, None, None
    except Exception as e:
        return False, None, None

async def fetch_store_batches(session, token):
    """Fetch ALL batches using the store token with pagination."""
    if not token:
        return []
    
    headers = {
        "api-version": "35",
        "app-version": "1.4.73.2",
        "device-id": "scanner_bot",
        "region": "IN",
    }
    
    all_batches = []
    page = 0
    
    while True:
        url = f"https://api.classplusapp.com/v2/course/preview/similar/{token}?limit=100&page={page}"
        try:
            async with session.get(url, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    batches = data.get("data", {}).get("coursesData", [])
                    
                    if not batches:
                        break
                    
                    all_batches.extend(batches)
                    page += 1
                    
                    if len(batches) < 100:
                        break
                else:
                    break
        except Exception as e:
            print(f"Error fetching batches page {page}: {e}")
            break
    
    return all_batches

async def fetch_batch_content(session, batch_token, file_handle, folder_id=0, folder_path=""):
    """Recursively fetch content for a batch and write to file."""
    url = f"https://api.classplusapp.com/v2/course/preview/content/list/{batch_token}"
    params = {'folderId': folder_id, 'limit': 9999}
    headers = {
        "api-version": "35",
        "app-version": "1.4.73.2",
        "device-id": "scanner_bot",
        "region": "IN",
    }
    
    count = 0
    try:
        # Limit concurrent folder fetches
        async with folder_semaphore:
            async with session.get(url, params=params, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    items = data.get("data", [])
                    
                    tasks = []
                    for item in items:
                        if item.get("contentType") == 1:  # Folder
                            folder_name = item.get("name", "Untitled")
                            new_path = f"{folder_path}({folder_name})"
                            tasks.append(fetch_batch_content(session, batch_token, file_handle, item.get("id"), new_path))
                        else:
                            name = item.get("name", "Untitled")
                            
                            # Try to find the ID from various possible fields
                            video_id = item.get("contentHashId") or item.get("hash") or item.get("videoId")
                            thumbnail_url = item.get("thumbnailUrl", "")
                            
                            url_val = None
                            
                            # Logic 1: Check if thumbnail has /cc/ pattern (New DRM)
                            if "/cc/" in thumbnail_url:
                                base_url = thumbnail_url.rsplit('/', 1)[0]
                                url_val = f"{base_url}/master.m3u8"
                            
                            # Logic 2: Check if thumbnail has /drm/wv/ pattern (Widevine DRM)
                            elif "/drm/wv/" in thumbnail_url:
                                base_url = thumbnail_url.rsplit('/', 1)[0]
                                url_val = f"{base_url}/master.m3u8"
                                
                            # Logic 3: Use explicit video ID if found (and not handled by above)
                            elif video_id and not url_val:
                                url_val = f"https://media-cdn.classplusapp.com/drm/{video_id}/playlist.m3u8"
                                
                            # Logic 4: Fallback to existing URL or thumbnail
                            if not url_val:
                                url_val = item.get("url") or thumbnail_url
                                
                            if url_val:
                                # Write directly to file (async)
                                await file_handle.write(f"{folder_path}{name}:{url_val}\n")
                                count += 1
                    
                    if tasks:
                        sub_counts = await asyncio.gather(*tasks)
                        count += sum(sub_counts)
    except Exception as e:
        print(f"Error fetching content: {e}")
        
    return count

async def process_valid_org(client, message, org_code, token, org_name):
    """Process a valid org: fetch batches, extract content, send files."""
    from Extractor.core.sender import MultiBotSender
    
    # Use semaphore to limit concurrent processing and prevent memory overflow
    async with processing_semaphore:
        try:
            print(f"[PROCESS] Starting to process org: {org_code} ({org_name})")
            # Create own session since this runs as background task
            # Use limited connector to prevent network saturation
            connector = aiohttp.TCPConnector(limit=100)
            async with aiohttp.ClientSession(connector=connector) as session:
                # Add timeout for fetching batches (15 seconds max)
                try:
                    batches = await asyncio.wait_for(
                        fetch_store_batches(session, token),
                        timeout=15.0
                    )
                except asyncio.TimeoutError:
                    print(f"[PROCESS ERROR] Timeout fetching batches for {org_code}")
                    await MultiBotSender.send_message(
                        SCANNER_LOG_CHANNEL,
                        f"⚠️ **Timeout processing org: {org_code}**\n"
                        f"📛 **Name:** {org_name}"
                    )
                    return
                
                if not batches:
                    print(f"[PROCESS] No batches found for {org_code}")
                    await MultiBotSender.send_message(
                        SCANNER_LOG_CHANNEL,
                        f"✅ **Valid Org: {org_code}**\n"
                        f"📛 **Name:** {org_name}\n"
                        f"⚠️ No public batches found"
                    )
                    if PREMIUM_LOGS:
                        await MultiBotSender.send_message(PREMIUM_LOGS, f"✅ Valid Org: {org_code} ({org_name}) - No batches")
                    return
                
                print(f"[PROCESS] Found {len(batches)} batches for {org_code}")
                await MultiBotSender.send_message(
                    SCANNER_LOG_CHANNEL, 
                    f"🎯 **Valid Org Found!**\n"
                    f"📛 **Name:** {org_name}\n"
                    f"🔤 **Code:** {org_code}\n"
                    f"📚 **Batches:** {len(batches)}\n"
                    f"⏳ Extracting content..."
                )

                for batch in batches:
                    batch_name = batch.get("name", "Unknown Batch")
                    batch_id = batch.get("id")
                    print(f"[DEBUG] Processing batch: {batch_name} (ID: {batch_id})")
                    
                    # Get batch token for content extraction
                    info_url = "https://api.classplusapp.com/v2/course/preview/org/info"
                    info_params = {'courseId': batch_id}
                    info_headers = {
                        "api-version": "22",
                        "tutorWebsiteDomain": f"https://{org_code}.courses.store"
                    }
                    
                    batch_token = None
                    try:
                        async with session.get(info_url, params=info_params, headers=info_headers, timeout=5) as resp:
                            if resp.status == 200:
                                data = await resp.json()
                                batch_token = data.get("data", {}).get("hash")
                                print(f"[DEBUG] Got batch token for {batch_name}: {batch_token}")
                            else:
                                print(f"[DEBUG] Failed to get batch token. Status: {resp.status}")
                    except Exception as e:
                        print(f"[PROCESS ERROR] Failed to get batch token for {batch_name} in {org_code}: {e}")
                        continue
                    
                    if batch_token:
                        # Sanitize filename for Windows
                        raw_filename = f"{org_name}_{batch_name}_{org_code}.txt"
                        filename = re.sub(r'[<>:"/\\|?*]', '_', raw_filename)
                        
                        # Pass batch name as the root folder
                        # Stream content directly to file to save memory
                        total_links = 0
                        start_time = time.time()
                        try:
                            print(f"[DEBUG] Starting content fetch for {batch_name}...")
                            async with aiofiles.open(filename, "w", encoding="utf-8") as f:
                                # Add timeout for content extraction (300 seconds max per batch)
                                total_links = await asyncio.wait_for(
                                    fetch_batch_content(session, batch_token, f, folder_path=f"({batch_name})"),
                                    timeout=300.0
                                )
                            end_time = time.time()
                            duration_seconds = int(end_time - start_time)
                            print(f"[PROCESS] Extracted {total_links} links from {batch_name} in {org_code}")
                        except asyncio.TimeoutError:
                            print(f"[PROCESS ERROR] Timeout extracting content for {batch_name} in {org_code}")
                            if os.path.exists(filename):
                                os.remove(filename)
                            continue
                        except Exception as e:
                            print(f"[PROCESS ERROR] Error writing file {filename}: {e}")
                            if os.path.exists(filename):
                                os.remove(filename)
                            continue

                        if total_links > 0:
                            # Count content types
                            video_count = 0
                            pdf_count = 0
                            image_count = 0
                            
                            try:
                                async with aiofiles.open(filename, "r", encoding="utf-8") as f:
                                    async for line in f:
                                        if ".mp4" in line or ".m3u8" in line:
                                            video_count += 1
                                        elif ".pdf" in line:
                                            pdf_count += 1
                                        elif ".jpg" in line or ".png" in line or ".jpeg" in line:
                                            image_count += 1
                            except Exception as e:
                                print(f"[DEBUG] Error counting content types: {e}")
                            
                            # Get batch details with safe defaults
                            price = batch.get("price", "Free")
                            if price == 0 or price == "0":
                                price = "Free"
                            start_date = batch.get("startDate", "N/A")
                            end_date = batch.get("endDate", "None")
                            
                            # Format time taken
                            hours, remainder = divmod(duration_seconds, 3600)
                            minutes, seconds = divmod(remainder, 60)
                            time_str = f"{hours}:{minutes:02}:{seconds:02}"
                            
                            # Get current time in IST
                            from datetime import datetime
                            import pytz
                            india_tz = pytz.timezone('Asia/Kolkata')
                            current_time = datetime.now(india_tz).strftime("%d-%m-%Y %I:%M %p")
                            
                            caption = (
                                f"🎯 <b>{org_name.upper()} [{'FREE' if price == 'Free' else 'PAID'}]</b>\n\n"
                                f"🔑 <b>ᴄᴏᴅᴇ:</b> {org_code}\n"
                                f"📝 <b>ʙᴀᴛᴄʜ:</b> {batch_name}\n\n"
                                f"💰 <b>ᴘʀɪᴄᴇ:</b> ₹{price}\n"
                                f"📅 <b>ꜱᴛᴀʀᴛ:</b> {start_date}\n"
                                f"📅 <b>ᴇɴᴅ:</b> {end_date}\n"
                                f"📊 <b>ᴄᴏɴᴛᴇɴᴛ ᴅᴇᴛᴀɪʟꜱ:</b>\n"
                                f"├─⭓ 🎬 <b>ᴠɪᴅᴇᴏꜱ:</b> {video_count}\n"
                                f"├─⭓ 📑 <b>ᴘᴅꜰꜱ:</b> {pdf_count}\n"
                                f"└─⭓ 🖼 <b>ɪᴍᴀɢᴇꜱ:</b> {image_count}\n\n"
                                f"🤖 <b>ᴜꜱɪɴɢ:</b> {BOT_TEXT}\n"
                                f"⏱ <b>ᴛɪᴍᴇ ᴛᴀᴋᴇɴ:</b> {time_str}\n"
                                f"📅 <b>ᴅᴀᴛᴇ:</b> {current_time}\n\n"
                                f"👑 <b>EXTRACTED BY SCANNER</b>\n\n"
                                f"━━━━━━━━━━━━━━━━━━━━━\n"
                                f"🌟 <b>Auto Scanner Bot</b>\n"
                                f"━━━━━━━━━━━━━━━━━━━━━"
                            )
                            
                            try:
                                print(f"[DEBUG] Sending file {filename}...")
                                # Send file using MultiBotSender with fallback to user chat
                                await MultiBotSender.send_document_with_fallback(
                                    client, 
                                    message, 
                                    filename, 
                                    caption, 
                                    channel_id=SCANNER_FILE_CHANNEL
                                )
                                print(f"[PROCESS] Sent file for {batch_name} in {org_code}")
                            except Exception as e:
                                print(f"[PROCESS ERROR] Error sending file {filename}: {e}")
                            finally:
                                if os.path.exists(filename):
                                    os.remove(filename)
                        else:
                            print(f"[DEBUG] No links found for {batch_name}, deleting empty file.")
                            # Clean up empty file
                            if os.path.exists(filename):
                                os.remove(filename)
                    else:
                        print(f"[DEBUG] No batch token found for {batch_name}")
                
                print(f"[PROCESS] Completed processing org: {org_code}")
        except Exception as e:
            print(f"[PROCESS ERROR] Unexpected error processing org {org_code}: {e}")
            import traceback
            traceback.print_exc()

async def check_codes_batch(session, codes):
    """Check multiple org codes in parallel and return valid ones."""
    tasks = [check_org_validity(session, code) for code in codes]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    valid_orgs = []
    for code, result in zip(codes, results):
        if isinstance(result, Exception):
            continue
        is_valid, token, org_name = result
        if is_valid:
            valid_orgs.append((code, token, org_name))
    
    return valid_orgs

async def scanner_loop(client, message):
    from Extractor.core.sender import MultiBotSender
    scan_state.start_time = time.time()
    
    await MultiBotSender.send_message(
        message.chat.id,
        f"🚀 **Scanner Started (Balanced Mode)**\n"
        f"📍 Starting from: `{scan_state.current_code}`\n"
        f"⚡ Checking 1000 codes at a time\n"
        f"ℹ️ Use /scan_status to check progress"
    )
    
    # Batch size for parallel validation
    # 1000 for local balanced mode
    BATCH_SIZE = 100 if IS_CLOUD else 1000
    
    # Configure connector to remove connection limits
    connector = aiohttp.TCPConnector(limit=0, ttl_dns_cache=300)
    async with aiohttp.ClientSession(connector=connector) as session:
        while scan_state.is_scanning:
            # Generate a batch of codes to check
            codes_to_check = []
            current = scan_state.current_code
            for _ in range(BATCH_SIZE):
                codes_to_check.append(current)
                current = next_code(current)
            
            # Check all codes in batch concurrently
            valid_orgs = await check_codes_batch(session, codes_to_check)
            
            # Update scan count
            scan_state.scanned_count += len(codes_to_check)
            
            # Process valid orgs
            for code, token, org_name in valid_orgs:
                scan_state.found_orgs.append(code)
                print(f"[SCAN] Valid org found: {code} ({org_name})")
                
                # Run org processing in background
                # Pass the client that triggered the scan command
                task = asyncio.create_task(process_valid_org(client, message, code, token, org_name))
                task.add_done_callback(lambda t: print(f"[TASK ERROR] {t.exception()}") if t.exception() else None)
            
            # Update current code to last checked code
            scan_state.current_code = current
            
            # Save progress less frequently to reduce I/O blocking
            if scan_state.scanned_count % 500 == 0:
                scan_state.save()
            
            # Check if we reached the end code
            if scan_state.end_code:
                # If current code is greater than end code, stop
                if compare_codes(scan_state.current_code, scan_state.end_code) > 0:
                    print(f"[SCAN] Reached end code limit: {scan_state.end_code}")
                    scan_state.is_scanning = False
                    await MultiBotSender.send_message(
                        message.chat.id, 
                        f"🏁 **Scan Range Completed**\n"
                        f"Reached limit: `{scan_state.end_code}`\n"
                        f"Total scanned: {scan_state.scanned_count}"
                    )
                    break

            # No delay for maximum speed
            if IS_CLOUD:
                await asyncio.sleep(0.01)
            else:
                await asyncio.sleep(0)

    # Final save
    scan_state.save()
    await MultiBotSender.send_message(message.chat.id, "🛑 **Scanner Stopped**")

from pyrogram.handlers import MessageHandler
from Extractor import apps

# ... (ScanState class and other helper functions remain unchanged) ...

# Define handlers as standalone functions (remove decorators)

async def start_scan(client, message):
    from Extractor.core.sender import MultiBotSender
    try:
        print(f"[SCAN] Command received from user {message.from_user.id} on bot {client.name}")
        
        if scan_state.is_scanning:
            await MultiBotSender.send_message(message.chat.id, "⚠️ Scanner is already running!")
            return
        
        args = message.command
        if len(args) > 1:
            start_code = args[1]
            end_code = args[2] if len(args) > 2 else None
            
            if start_code.isalpha() and len(start_code) >= 2:
                scan_state.current_code = start_code.lower()
                print(f"[SCAN] Starting from custom code: {scan_state.current_code}")
                
                if end_code:
                    if end_code.isalpha() and len(end_code) >= 2:
                        # Validate range
                        if compare_codes(start_code, end_code) > 0:
                             await MultiBotSender.send_message(message.chat.id, "⚠️ Invalid range: Start code is greater than End code.")
                             return
                        scan_state.end_code = end_code.lower()
                        print(f"[SCAN] Set end code limit: {scan_state.end_code}")
                    else:
                        await MultiBotSender.send_message(message.chat.id, "⚠️ Invalid end code (must be 2+ letters). Ignoring limit.")
                else:
                    scan_state.end_code = None # Reset if not provided
            else:
                await MultiBotSender.send_message(message.chat.id, "⚠️ Invalid start code (must be 2+ letters). Using saved/default code.")
                print(f"[SCAN] Invalid start code: {start_code}")
        else:
            print(f"[SCAN] Starting from default/saved code: {scan_state.current_code}")
        
        scan_state.is_scanning = True
        asyncio.create_task(scanner_loop(client, message))
        print(f"[SCAN] Scanner task created successfully")
    except Exception as e:
        print(f"[SCAN ERROR] {e}")
        import traceback
        traceback.print_exc()
        await MultiBotSender.send_message(message.chat.id, f"❌ Error starting scanner: {str(e)}")

async def stop_scan(client, message):
    from Extractor.core.sender import MultiBotSender
    if not scan_state.is_scanning:
        await MultiBotSender.send_message(message.chat.id, "⚠️ Scanner is not running.")
        return
    
    scan_state.is_scanning = False
    scan_state.save()
    await MultiBotSender.send_message(message.chat.id, "🛑 Stopping scanner... (finishing current task)")

async def status_scan(client, message):
    from Extractor.core.sender import MultiBotSender
    duration = time.time() - scan_state.start_time if scan_state.is_scanning else 0
    status = "Running 🟢" if scan_state.is_scanning else "Stopped 🔴"
    
    text = (
        f"📊 **Scanner Status** (PID: {os.getpid()})\n\n"
        f"Status: {status}\n"
        f"Current Code: `{scan_state.current_code}`\n"
        f"End Code: `{scan_state.end_code if scan_state.end_code else 'None'}`\n"
        f"Scanned: {scan_state.scanned_count}\n"
        f"Found: {len(scan_state.found_orgs)}\n"
        f"Duration: {int(duration)}s\n\n"
        f"Found Orgs: {', '.join(scan_state.found_orgs[-10:])}"
    )
    await MultiBotSender.send_message(message.chat.id, text)

async def test_scan_module(client, message):
    """Test if scan module is loaded and responding."""
    from Extractor.core.sender import MultiBotSender
    await MultiBotSender.send_message(
        message.chat.id,
        "✅ **Scan Module Loaded**\n\n"
        f"Scanner is: {'Running 🟢' if scan_state.is_scanning else 'Stopped 🔴'}\n"
        f"Current code: `{scan_state.current_code}`\n"
        f"Commands available: /scan_org, /stop_scan, /scan_status, /test_channel"
    )

async def test_channel_command(client, message):
    """Test sending a message to the target channel with ALL bots."""
    from Extractor.core.sender import MultiBotSender
    target_chat_id = -1003346181666
    
    # Use MultiBotSender for the initial status message
    status_msg = await MultiBotSender.send_message(message.chat.id, f"🔄 Testing connection for {len(apps)} bots...")
    
    results = []
    for i, app_client in enumerate(apps):
        bot_name = app_client.name
        try:
            sent = await app_client.send_message(
                chat_id=target_chat_id,
                text=f"✅ **Test Message**\n\nBot `{bot_name}` connection verified.\nTriggered by {message.from_user.mention}"
            )
            results.append(f"✅ Bot {i+1} ({bot_name}): Success")
        except Exception as e:
            results.append(f"❌ Bot {i+1} ({bot_name}): Failed ({e})")
    
    final_text = "**Test Results:**\n\n" + "\n".join(results)
    
    # Use MultiBotSender to edit the status message (or send new if edit fails)
    await MultiBotSender.edit_message(client, message.chat.id, status_msg.id, final_text)

# Register handlers for ALL bots
print("[SCAN] Registering handlers for all bots...")
for client in apps:
    client.add_handler(MessageHandler(start_scan, filters.command("scan_org")))
    client.add_handler(MessageHandler(stop_scan, filters.command("stop_scan")))
    client.add_handler(MessageHandler(status_scan, filters.command("scan_status")))
    client.add_handler(MessageHandler(test_scan_module, filters.command("test_scan")))
    client.add_handler(MessageHandler(test_channel_command, filters.command(["test_channel", "testchannel"])))
print(f"[SCAN] Handlers registered for {len(apps)} bots.")
