import asyncio
import logging
import os
from pyromod import listen
from pyrogram import Client
from config import API_ID, API_HASH, BOT_TOKENS

# Create sessions directory if it doesn't exist
if not os.path.exists("sessions"):
    os.makedirs("sessions")

loop = asyncio.get_event_loop()

logging.basicConfig(
    format="[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s",
    level=logging.INFO,
)

apps = []
for i, token in enumerate(BOT_TOKENS):
    client = Client(
        f"Extractor_{i}",
        api_id=API_ID,
        api_hash=API_HASH,
        bot_token=token,
        workdir="sessions",
        workers=200,
        sleep_threshold=0, # Fail immediately on FloodWait so we can switch bots
    )
    apps.append(client)

app = apps[0] # Primary app for backward compatibility

# Initialize pyromod attributes for all apps
for client in apps:
    client.listening = {}
    client.listening_cb = {}
    client.waiting_input = {}

# Global bot info variables (will be set by __main__.py after app.start())
BOT_ID = None
BOT_NAME = None
BOT_USERNAME = None
